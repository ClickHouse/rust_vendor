# cityhash-rs

This crate provides pure-rust `no_std` implementations of [cityhash](https://github.com/google/cityhash) versions v1.0.2, v1.0.3, and v1.1.0. 

Note that only `CityHash128` is supported at the moment, `CityHash64` and `CityHash32` are not supported. If anyone needs them, let me know and I can write them up.