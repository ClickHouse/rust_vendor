//TODO: replace with builtin SIMD type

// FIXME!!!
#[allow(dead_code)]
#[derive(Copy, Clone, Default, Debug)]
pub struct PDF([i16; 16]);
