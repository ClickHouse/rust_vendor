#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/**
 * The root of all evil.
 */
void root(void);

/**
 * A little above the root, and a lot more visible, with a run-on sentence
 */
void trunk(void);

#ifdef __cplusplus
}  // extern "C"
#endif  // __cplusplus
