#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

enum class StyleOnlyThisShouldBeGenerated : uint8_t {
  Foo,
  Bar,
};
