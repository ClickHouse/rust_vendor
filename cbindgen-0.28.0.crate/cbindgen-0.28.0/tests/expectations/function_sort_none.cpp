#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

extern "C" {

void C();

void B();

void D();

void A();

}  // extern "C"
