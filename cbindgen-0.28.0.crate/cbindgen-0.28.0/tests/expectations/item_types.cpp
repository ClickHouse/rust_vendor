#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

enum class OnlyThisShouldBeGenerated : uint8_t {
  Foo,
  Bar,
};
