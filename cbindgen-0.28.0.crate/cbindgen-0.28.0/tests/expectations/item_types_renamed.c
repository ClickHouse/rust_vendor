#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

enum StyleOnlyThisShouldBeGenerated {
  Foo,
  Bar,
};
typedef uint8_t StyleOnlyThisShouldBeGenerated;
