#![allow(non_upper_case_globals)]

use crate::co::*;

const_guid_values! { CLSID;
	TaskScheduler "0f87369f-a4e5-4cfc-bd3e-73e6154572dd"
}
