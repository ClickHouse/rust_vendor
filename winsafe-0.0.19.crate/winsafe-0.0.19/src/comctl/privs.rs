pub(crate) const CLR_DEFAULT: u32 = 0xff00_0000;
pub(crate) const GDT_ERROR: i32 = -1;
pub(crate) const HINST_COMMCTRL: isize = -1;
pub(crate) const I_IMAGECALLBACK: isize = -1;
pub(crate) const I_IMAGENONE: isize = -2;
pub(crate) const L_MAX_URL_LENGTH: usize = 2048 + 32 + 4;
pub(crate) const MAX_LINKID_TEXT: usize = 48;
