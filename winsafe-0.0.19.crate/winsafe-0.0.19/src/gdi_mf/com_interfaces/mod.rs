mod imfvideodisplaycontrol;

pub mod traits {
	pub use super::imfvideodisplaycontrol::gdi_mf_IMFVideoDisplayControl;
}
