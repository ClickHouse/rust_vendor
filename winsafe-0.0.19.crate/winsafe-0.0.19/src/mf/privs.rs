pub(crate) const MF_API_VERSION: u32 = 0x0070;
pub(crate) const MF_SDK_VERSION: u32 = 0x0002;
pub(crate) const MF_VERSION: u32 = MF_SDK_VERSION << 16 | MF_API_VERSION;
