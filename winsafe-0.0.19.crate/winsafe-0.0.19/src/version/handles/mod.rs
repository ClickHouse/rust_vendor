mod hversioninfo;

pub mod decl {
	pub use super::hversioninfo::HVERSIONINFO;
}

pub mod traits {
	pub use super::hversioninfo::version_Hversioninfo;
}
