pub(crate) const CLR_INVALID: u32 = 0xffff_ffff;
pub(crate) const GDI_ERROR: u32 = 0xffff_ffff;
pub(crate) const HIMETRIC_PER_INCH: i32 = 2540;
pub(crate) const LF_FACESIZE: usize = 32;
