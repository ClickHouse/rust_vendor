mod hwnd;

pub mod traits {
	pub use super::hwnd::dwm_Hwnd;
}
