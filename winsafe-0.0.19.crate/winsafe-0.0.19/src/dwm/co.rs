#![allow(non_camel_case_types)]

const_ordinary! { DWM_SIT: u32;
	/// [`DwmSetIconicLivePreviewBitmap`](crate::prelude::dwm_Hwnd::DwmSetIconicLivePreviewBitmap)
	/// `sit_flags` (`u32`).
	=>
	=>
	DISPLAYFRAME 0x0000_0001
}
