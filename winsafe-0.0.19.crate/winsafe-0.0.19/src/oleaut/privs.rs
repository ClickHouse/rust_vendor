pub(crate) const PID_FIRST_USABLE: u32 = 0x2;
