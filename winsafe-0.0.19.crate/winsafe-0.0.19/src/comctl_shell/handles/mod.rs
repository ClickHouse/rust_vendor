mod himagelist;

pub mod traits {
	pub use super::himagelist::comctl_shell_Himagelist;
}
