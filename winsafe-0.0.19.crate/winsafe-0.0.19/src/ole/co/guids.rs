const_guid! { CLSID;
	/// A COM class ID, from which the interfaces are created (`GUID`).
	=>
}

const_guid! { IID;
	/// A COM interface ID, which uniquely identifies the interface (`GUID`).
	=>
}
