mod hwnd;

pub mod traits {
	pub use super::hwnd::ole_Hwnd;
}
