/// This module simply imports all tests.
/// That way, they're processed faster, which is nice as proptesting takes quite a while.
mod all;
