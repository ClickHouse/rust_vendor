# icu_normalizer_data [![crates.io](https://img.shields.io/crates/v/icu_normalizer_data)](https://crates.io/crates/icu_normalizer_data)

<!-- cargo-rdme start -->

Data for the `icu_normalizer` crate

This data was generated with CLDR version 46.0.0-BETA2, ICU version icu4x/2024-05-16/75.x, and
LSTM segmenter version v0.1.0.

<!-- cargo-rdme end -->

## More Information

For more information on development, authorship, contributing etc. please visit [`ICU4X home page`](https://github.com/unicode-org/icu4x).
