/// `sysinfo`
pub type Sysinfo = linux_raw_sys::system::sysinfo;

pub(crate) type RawUname = linux_raw_sys::system::new_utsname;
