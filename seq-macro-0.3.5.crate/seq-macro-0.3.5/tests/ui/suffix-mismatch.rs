use seq_macro::seq;

seq!(N in 0u8..1u16 {});

fn main() {}
