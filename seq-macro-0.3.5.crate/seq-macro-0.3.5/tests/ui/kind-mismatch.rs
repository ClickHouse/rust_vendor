use seq_macro::seq;

seq!(N in 'a'..b'z' {});

fn main() {}
