Contributions are welcome! Just create a pull request.
