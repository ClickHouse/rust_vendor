# g2gen
See [g2p](https://docs.rs/g2p)

## License
Licensed under the Apache License, Version 2.0 [LICENSE-APACHE](LICENSE-APACHE)
or the MIT license [LICENSE-MIT](LICENSE-MIT)>, at your
option.
