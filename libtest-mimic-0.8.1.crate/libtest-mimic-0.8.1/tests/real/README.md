# Test files to check the behavior of the real libtest

These are just files that are not actively used but are useful to check the behavior of the real libtest.
Just `rustc --test <file>` and execute it.
