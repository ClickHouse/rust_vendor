Examples
========

- `simple`: five dummy tests are created and executed
- **`tidy`**: most useful example. Generates a test for each `.rs` file and runs a simply tidy script as test.
