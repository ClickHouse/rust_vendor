Builder for [`{struct_name}`](struct.{struct_name}.html).
