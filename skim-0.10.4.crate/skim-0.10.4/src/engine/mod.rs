pub mod all;
pub mod andor;
pub mod exact;
pub mod factory;
pub mod fuzzy;
pub mod regexp;
mod util;
