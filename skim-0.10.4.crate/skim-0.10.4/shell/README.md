This directory contains the shell bindings for skim. 

Note that the content in this directory is copied from
[fzf](https://github.com/junegunn/fzf/tree/master/shell) and modified to fit
skim.

The scripts in this directory will not be maintained by skim.

But you are welcome to submit PR for update the scripts to the fzf's latest
scripts. Thanks!
