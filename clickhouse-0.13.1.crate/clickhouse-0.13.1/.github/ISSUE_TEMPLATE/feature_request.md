---
name: Feature request
about: Suggest an idea for the client
title: ''
labels: enhancement
assignees: ''

---

<!-- delete unnecessary items -->
### Use case

### Describe the solution you'd like

### Describe the alternatives you've considered

### Additional context
