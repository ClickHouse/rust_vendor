fn main() {
    eprintln!("{:?}", "STDERR".chars());
}
