Internal build script for [chrono-tz](https://github.com/chronotope/chrono-tz)
